/**
 * Google Apps Script - DGMA Monitor Webhook Handler
 *
 * Receives data from GitHub Actions bot
 * Appends to Google Sheet
 * Sends Telegram notifications
 *
 * Setup:
 * 1. Go to https://script.google.com
 * 2. Create new project
 * 3. Paste this code
 * 4. Add Script Properties:
 *    - TELEGRAM_TOKEN
 *    - TELEGRAM_CHAT_ID
 *    - SHEET_ID
 * 5. Deploy as Web App (Execute as: Me, Who can access: Anyone)
 * 6. Copy deployment URL
 * 7. Add to GitHub Secrets as GAS_ENDPOINT
 */

const CONFIG = {
  TELEGRAM_TOKEN: PropertiesService.getScriptProperties().getProperty('TELEGRAM_TOKEN'),
  TELEGRAM_CHAT_ID: PropertiesService.getScriptProperties().getProperty('TELEGRAM_CHAT_ID'),
  SHEET_ID: PropertiesService.getScriptProperties().getProperty('SHEET_ID')
};

// ===== WEBHOOK HANDLER =====
function doPost(e) {
  try {
    const data = JSON.parse(e.postData.contents);
    Logger.log('Received: ' + JSON.stringify(data));

    // Append to sheet
    appendToSheet(data);

    // Send notification
    if (data.exam_date || data.oral_link) {
      sendNotification(data);
    }

    return ContentService.createTextOutput(JSON.stringify({
      status: 'success',
      message: 'Data received and processed'
    })).setMimeType(ContentService.MimeType.JSON);

  } catch (error) {
    Logger.log('Error: ' + error.toString());
    return ContentService.createTextOutput(JSON.stringify({
      status: 'error',
      message: error.toString()
    })).setMimeType(ContentService.MimeType.JSON);
  }
}

// ===== APPEND TO GOOGLE SHEET =====
function appendToSheet(data) {
  try {
    const sheet = SpreadsheetApp.openById(CONFIG.SHEET_ID).getActiveSheet();

    // Add header if empty
    if (sheet.getLastRow() === 0) {
      sheet.appendRow([
        'Timestamp',
        'Exam Date',
        'Oral Link',
        'Status'
      ]);
    }

    // Append row
    const timestamp = new Date().toLocaleString();
    sheet.appendRow([
      timestamp,
      data.exam_date || '',
      data.oral_link || '',
      data.status || 'OK'
    ]);

    Logger.log('✓ Appended to sheet');

  } catch (error) {
    Logger.log('Sheet error: ' + error.toString());
  }
}

// ===== SEND TELEGRAM NOTIFICATION =====
function sendNotification(data) {
  try {
    let message = '<b>📊 DGMA Exam Status Update</b>\n\n';

    if (data.exam_date) {
      message += `📅 <b>Exam Date:</b> <code>${data.exam_date}</code>\n`;
    }

    if (data.oral_link) {
      message += `🎙️ <b>Oral Link:</b> <a href="${data.oral_link}">Click to Open</a>\n`;
    }

    message += `\n⏰ ${new Date().toLocaleString()}`;

    const telegramUrl = `https://api.telegram.org/bot${CONFIG.TELEGRAM_TOKEN}/sendMessage`;

    UrlFetchApp.fetch(telegramUrl, {
      method: 'post',
      payload: {
        chat_id: CONFIG.TELEGRAM_CHAT_ID,
        text: message,
        parse_mode: 'HTML',
        disable_web_page_preview: true
      },
      muteHttpExceptions: true
    });

    Logger.log('✓ Telegram notification sent');

  } catch (error) {
    Logger.log('Telegram error: ' + error.toString());
  }
}

// ===== TEST FUNCTION =====
function testSetup() {
  Logger.log('Testing configuration...');
  Logger.log('TELEGRAM_TOKEN: ' + (CONFIG.TELEGRAM_TOKEN ? '✓' : '❌'));
  Logger.log('TELEGRAM_CHAT_ID: ' + (CONFIG.TELEGRAM_CHAT_ID ? '✓' : '❌'));
  Logger.log('SHEET_ID: ' + (CONFIG.SHEET_ID ? '✓' : '❌'));

  // Test Telegram
  const url = `https://api.telegram.org/bot${CONFIG.TELEGRAM_TOKEN}/sendMessage`;
  UrlFetchApp.fetch(url, {
    method: 'post',
    payload: {
      chat_id: CONFIG.TELEGRAM_CHAT_ID,
      text: '✅ Google Apps Script is working!'
    },
    muteHttpExceptions: true
  });

  Logger.log('✓ Test message sent to Telegram');
}

// ===== MANUAL TEST =====
function manualTest() {
  const testData = {
    timestamp: new Date().toISOString(),
    exam_date: '15-10-2026',
    oral_link: 'https://meet.google.com/abc-defg-hij',
    status: 'OK'
  };

  appendToSheet(testData);
  sendNotification(testData);

  Logger.log('✓ Manual test completed');
}
