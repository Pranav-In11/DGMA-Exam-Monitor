# 📚 Complete Setup Guide - GitHub + Google Sheets + Apps Script

## 🎯 Architecture

```
Your Computer (code editing)
    ↓
GitHub Repository (stores code)
    ↓
GitHub Actions (runs bot hourly)
    ↓
Python Script (dgma_bot.py)
    ↓
Google Apps Script (receives data + sends Telegram)
    ↓
Google Sheets (stores results)
    ↓
Telegram (notifications)
```

---

## 📋 Prerequisites

✅ GitHub account  
✅ Google account (for Sheets & Apps Script)  
✅ Telegram bot token  
✅ DGMA credentials  

---

## 🚀 Step-by-Step Setup (30 minutes)

### Step 1: Create GitHub Repository

```bash
# Option A: Clone this repo (if you have it)
git clone https://github.com/YOUR_USERNAME/dgma-monitor.git
cd dgma-monitor

# Option B: Create new repo
mkdir dgma-monitor
cd dgma-monitor
git init
git remote add origin https://github.com/YOUR_USERNAME/dgma-monitor.git
```

### Step 2: Copy Files

Copy all files from this setup to your repo:

```
dgma-monitor/
├── .github/workflows/check-dgma.yml
├── src/
│   ├── dgma_bot.py
│   └── requirements.txt
├── .env.example
├── gas_script.gs
└── README.md
```

### Step 3: Create Google Sheet

```
1. Go to: https://sheets.google.com
2. Create new sheet: "DGMA Exam Monitor"
3. Copy Sheet ID from URL:
   https://docs.google.com/spreadsheets/d/COPY_THIS_ID/edit
```

### Step 4: Deploy Google Apps Script

```
1. Go to: https://script.google.com
2. New Project
3. Paste content from: gas_script.gs
4. Save
5. Add Script Properties:
   🔧 Project Settings → Script properties
   
   Property: TELEGRAM_TOKEN
   Value: [your_token]
   
   Property: TELEGRAM_CHAT_ID
   Value: [your_chat_id]
   
   Property: SHEET_ID
   Value: [your_sheet_id]

6. Test function:
   Select: testSetup
   Click: ▶️ Run
   Check Telegram: Should get message ✓

7. Deploy as Web App:
   Deploy → New deployment
   Type: Web app
   Execute as: Me
   Who can access: Anyone
   Deploy
   
   Copy the URL (looks like):
   https://script.google.com/macros/d/AKfycbx...
```

### Step 5: Add GitHub Secrets

```
1. Go to: GitHub → Your Repository → Settings
2. Secrets and variables → Actions
3. Add these secrets:

Name: TELEGRAM_TOKEN
Value: your_bot_token

Name: TELEGRAM_CHAT_ID
Value: your_chat_id

Name: SHEET_ID
Value: your_sheet_id

Name: DGMA_USERNAME
Value: your_indos_or_email

Name: DGMA_PASSWORD
Value: your_password

Name: GAS_ENDPOINT (optional)
Value: https://script.google.com/macros/d/YOUR_DEPLOYMENT_ID/usercontent
```

### Step 6: Push to GitHub

```bash
# Add all files
git add .

# Commit
git commit -m "Initial DGMA monitor setup"

# Push
git push origin main
```

### Step 7: Enable GitHub Actions

```
1. GitHub → Your Repository → Actions
2. Click "I understand my workflows, go ahead and enable them"
3. Done! Actions are enabled
```

### Step 8: Test Manually

```
GitHub → Actions → DGMA Exam Monitor
Click: Run workflow
Check: Telegram messages
Check: Google Sheet (new row added)
```

---

## ⏰ Schedule Configuration

Edit `.github/workflows/check-dgma.yml`:

**Current:** Every hour
```yaml
- cron: '0 * * * *'
```

**Other options:**

Daily at 9 AM:
```yaml
- cron: '0 9 * * *'
```

Every 6 hours:
```yaml
- cron: '0 */6 * * *'
```

Every day at 9 AM and 3 PM:
```yaml
- cron: '0 9,15 * * *'
```

---

## 🔧 File Descriptions

| File | Purpose |
|------|---------|
| `.github/workflows/check-dgma.yml` | GitHub Actions workflow (schedule + run) |
| `src/dgma_bot.py` | Main bot script (login + scrape + notify) |
| `src/requirements.txt` | Python dependencies |
| `gas_script.gs` | Google Apps Script (receive + store + notify) |
| `.env.example` | Environment variables template |

---

## 📊 How It Works

### Every Hour (GitHub Actions):

1. **Triggers** - GitHub Actions starts
2. **Setup** - Installs Python packages
3. **Run** - Executes dgma_bot.py
4. **Login** - Connects to DGMA portal
5. **Scrape** - Gets exam date & oral link
6. **Send** - Posts data to Google Apps Script

### Google Apps Script Receives Data:

1. **Webhook** - Receives POST from Python script
2. **Sheet** - Appends row to Google Sheets
3. **Notify** - Sends Telegram message
4. **Log** - Records in Apps Script logs

### Google Sheets:

1. **Row Added** - Timestamp, exam date, oral link
2. **History** - All checks stored
3. **Searchable** - Easy to find when changes happened

---

## 🆘 Troubleshooting

### ❌ Actions fail with "Insufficient permissions"

**Fix:**
```
GitHub → Settings → Actions → General
Scroll down → Workflow permissions
Select: "Read and write permissions"
Check: "Allow GitHub Actions to create and approve pull requests"
Save
```

### ❌ "secrets not found"

**Check:**
```
1. Go to Settings → Secrets and variables → Actions
2. Verify all 5 secrets are there
3. Secret names are CASE-SENSITIVE
4. No extra spaces in values
```

### ❌ "Google Apps Script connection failed"

**Check:**
```
1. GAS_ENDPOINT URL is correct
2. Deployed as Web App (Execute as: Me)
3. "Who can access" is set to "Anyone"
4. Test manually with testSetup()
```

### ❌ "Google Sheet not found"

**Check:**
```
1. SHEET_ID is correct (from URL)
2. Sheet exists and you have access
3. Google Apps Script has permission
```

### ❌ No Telegram messages

**Check:**
```
1. TELEGRAM_TOKEN is correct
2. TELEGRAM_CHAT_ID is correct
3. You've sent a message to the bot
4. Bot has permission to message you
```

---

## 📱 Monitor

### GitHub Actions

```
GitHub → Actions → DGMA Exam Monitor
See all runs and logs
```

### Google Sheets

```
https://docs.google.com/spreadsheets/d/SHEET_ID/
View all historical data
```

### Telegram

```
Get real-time notifications
```

---

## 🎯 Customization

### Change Schedule

Edit `.github/workflows/check-dgma.yml`:
```yaml
schedule:
  - cron: '0 9 * * *'  # 9 AM daily
```

### Add Proxy

For Indian IP routing, add to GitHub Secrets:
```
Name: PROXY_URL
Value: http://proxy-server:8080
```

### Disable Telegram

Comment out `send_to_tg()` calls in `dgma_bot.py`

---

## ✅ Checklist

- [ ] GitHub repository created
- [ ] Files copied to repo
- [ ] Google Sheet created
- [ ] Google Apps Script deployed
- [ ] All 5 GitHub secrets added
- [ ] Code pushed to GitHub
- [ ] Actions enabled
- [ ] Manual test run successful
- [ ] Telegram messages received
- [ ] Google Sheet has data

---

## 🚀 You're Ready!

Your automation is now live:

✅ **GitHub Actions** - Runs bot on schedule  
✅ **Python Script** - Checks DGMA portal  
✅ **Google Apps Script** - Receives data & notifies  
✅ **Google Sheets** - Stores all results  
✅ **Telegram** - Real-time alerts  

**Cost: $0 forever**

---

## 📞 Support

- GitHub Actions: https://docs.github.com/en/actions
- Google Sheets API: https://developers.google.com/sheets/api
- Google Apps Script: https://developers.google.com/apps-script
- Telegram Bot API: https://core.telegram.org/bots/api

---

**All set! Your DGMA monitor is running 24/7 on GitHub** 🚀

