# 🤖 DGMA Exam Monitor - GitHub + Google Sheets + Apps Script

Complete automation framework with GitHub Actions, Google Sheets database, and Apps Script responses.

## 📋 Architecture

```
GitHub Repository (Code + Triggers)
    ↓
GitHub Actions (Worker on schedule)
    ↓
Python Bot (dgma_bot.py)
    ↓
Check DGMA Portal (Indian Proxy)
    ↓
Google Sheets (Database)
    ↓
Google Apps Script (Notifications via Telegram)
```

## 📁 Repository Structure

```
dgma-monitor/
├── .github/
│   └── workflows/
│       └── check-dgma.yml           # GitHub Actions workflow
├── src/
│   ├── dgma_bot.py                  # Main bot script
│   ├── requirements.txt              # Python dependencies
│   └── config.py                     # Configuration
├── scripts/
│   └── deploy.sh                     # Deployment script
├── .env.example                      # Environment template
├── README.md                         # This file
└── gas_script.gs                     # Google Apps Script (paste into GAS)
```

## 🚀 Quick Start

### 1. Fork/Clone Repository
```bash
git clone https://github.com/YOUR_USERNAME/dgma-monitor.git
cd dgma-monitor
```

### 2. Set GitHub Secrets
```
GitHub Settings → Secrets and variables → Actions
Add:
  - TELEGRAM_TOKEN
  - TELEGRAM_CHAT_ID
  - SHEET_ID
  - DGMA_USERNAME
  - DGMA_PASSWORD
```

### 3. Set Up Google Sheets
- Create sheet: https://sheets.google.com
- Copy Sheet ID
- Add to GitHub Secrets

### 4. Deploy Google Apps Script
- Go to https://script.google.com
- Create new project
- Paste content from `gas_script.gs`
- Add script properties
- Deploy

### 5. Push to GitHub
```bash
git add .
git commit -m "Initial commit"
git push origin main
```

Done! Actions run on schedule automatically.

## 📊 How It Works

1. **GitHub Actions** - Triggers daily/hourly
2. **Python Bot** - Runs on Actions worker
3. **Proxy** - Routes through Indian IP
4. **Google Sheets** - Stores results
5. **Google Apps Script** - Sends Telegram alerts

## 🔧 Configuration

### `.env` File
```
TELEGRAM_TOKEN=your_token
TELEGRAM_CHAT_ID=your_chat_id
SHEET_ID=your_sheet_id
DGMA_USERNAME=your_indos_or_email
DGMA_PASSWORD=your_password
PROXY_URL=optional_proxy_url
```

### `workflow.yml` Schedule
```yaml
schedule:
  - cron: '0 * * * *'  # Every hour
  # Change to: '0 9 * * *' for 9 AM daily
```

## 📱 What You Get

- ✅ Automatic daily checks
- ✅ Progress updates on Telegram
- ✅ Captcha image sharing if needed
- ✅ Manual captcha input support
- ✅ Google Sheets database
- ✅ Change alerts via Google Apps Script
- ✅ Cost: $0

## 🆘 Troubleshooting

See `SETUP_GUIDE.md` for detailed troubleshooting.

## 📄 Files

- **README.md** - This file
- **SETUP_GUIDE.md** - Detailed setup instructions
- **.github/workflows/check-dgma.yml** - GitHub Actions workflow
- **src/dgma_bot.py** - Main bot code
- **src/requirements.txt** - Python packages
- **gas_script.gs** - Google Apps Script

## 🔗 Links

- GitHub Actions: https://github.com/features/actions
- Google Sheets: https://sheets.google.com
- Google Apps Script: https://script.google.com
- Telegram Bot: https://t.me/BotFather

---

**Ready to deploy?** Follow `SETUP_GUIDE.md` 🚀
