# ⚡ Quick Reference - GitHub + Google Sheets + Apps Script

## 📋 5 Values You Need

```
1. TELEGRAM_TOKEN = 8543081508:AAFaOreUPEh2JQtyWgkKWS13fWXz2efgU4Q
2. TELEGRAM_CHAT_ID = 5209980624
3. SHEET_ID = 16V5fgmvbwWu3D6eF_R4fhTv5D4pEgq-SyNmdUyIcCeY
4. DGMA_USERNAME = your_indos_or_email
5. DGMA_PASSWORD = your_password
```

---

## 🚀 5-Step Deploy (30 minutes)

### 1. Create Google Sheet
```
sheets.google.com → New sheet
Copy Sheet ID from URL
```

### 2. Deploy Google Apps Script
```
script.google.com → New project
Paste gas_script.gs
Add 3 properties (TELEGRAM_TOKEN, TELEGRAM_CHAT_ID, SHEET_ID)
Deploy as Web App
Copy deployment URL
```

### 3. Create GitHub Repo
```
github.com → New repository
Clone locally
Add all files from this folder
```

### 4. Add GitHub Secrets
```
Settings → Secrets and variables → Actions
Add 5 secrets:
  - TELEGRAM_TOKEN
  - TELEGRAM_CHAT_ID
  - SHEET_ID
  - DGMA_USERNAME
  - DGMA_PASSWORD
  - GAS_ENDPOINT (optional)
```

### 5. Push & Run
```
git add .
git commit -m "Initial setup"
git push origin main
GitHub → Actions → Run workflow
```

---

## 📁 Folder Structure

```
.github/workflows/
  └── check-dgma.yml          # GitHub Actions trigger
src/
  ├── dgma_bot.py             # Main bot
  └── requirements.txt         # Python packages
.env.example                  # Config template
gas_script.gs                 # Google Apps Script
README.md                     # Overview
SETUP_GUIDE.md                # Detailed setup
QUICK_REFERENCE.md            # This file
```

---

## ⏰ Workflow Triggers

Edit `.github/workflows/check-dgma.yml`:

**Every hour:**
```yaml
- cron: '0 * * * *'
```

**Daily at 9 AM:**
```yaml
- cron: '0 9 * * *'
```

**Twice daily (9 AM & 6 PM):**
```yaml
- cron: '0 9,18 * * *'
```

---

## 🔍 What Happens

### GitHub Actions (Every hour)
```
1. Trigger → Python script starts
2. Login → Connect to DGMA
3. Scrape → Get exam date & oral link
4. Send → Post to Google Apps Script
```

### Google Apps Script
```
1. Receive → Data from Python
2. Sheet → Append row
3. Notify → Send Telegram message
```

### Result
```
✓ Google Sheet has new row
✓ Telegram gets notification
✓ Everything logged
```

---

## 🆘 Common Issues

| Issue | Fix |
|-------|-----|
| ❌ Secrets not found | Check Settings → Secrets (case-sensitive!) |
| ❌ GAS not receiving data | Check GAS_ENDPOINT URL is correct |
| ❌ No Telegram messages | Verify TELEGRAM_TOKEN & CHAT_ID |
| ❌ Sheet not updating | Check SHEET_ID in both places |
| ❌ Actions won't run | Enable Actions: Settings → Actions → General |

---

## 📊 Files at a Glance

| File | What It Does |
|------|-------------|
| `check-dgma.yml` | Schedules and runs bot hourly |
| `dgma_bot.py` | Logs in + scrapes + sends data |
| `requirements.txt` | Python packages needed |
| `gas_script.gs` | Receives data + saves + notifies |
| `.env.example` | Config template (copy to .env) |

---

## 🎯 Checklist

- [ ] Google Sheet created
- [ ] Google Apps Script deployed
- [ ] GitHub secrets added (5 values)
- [ ] Code pushed to GitHub
- [ ] Actions enabled
- [ ] Manual test run
- [ ] Telegram messages received
- [ ] Sheet has data

---

## 📱 Monitor Status

### GitHub Actions
```
GitHub → Your Repo → Actions
See all runs and logs
```

### Google Sheet
```
https://docs.google.com/spreadsheets/d/SHEET_ID/
Check for new rows
```

### Telegram
```
Get real-time notifications every hour
```

---

## 🚀 First Run

When you push to GitHub:
1. Actions should trigger automatically
2. Check Actions tab for status
3. First run may take 2-3 minutes
4. Check Telegram for messages
5. Check Google Sheet for data

---

## 🔐 Security Notes

✅ Secrets stored securely in GitHub  
✅ Passwords never logged  
✅ .env is in .gitignore  
✅ Only authorized users see output  

---

## 📞 Need Help?

See: `SETUP_GUIDE.md` for detailed instructions

---

**That's it! Your bot runs 24/7 on GitHub** ✨
