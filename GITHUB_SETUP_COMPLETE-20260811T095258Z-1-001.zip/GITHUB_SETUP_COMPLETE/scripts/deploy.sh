#!/bin/bash
# Quick deployment script for DGMA Monitor

set -e

echo "🚀 DGMA Monitor - Quick Deploy"
echo "=============================="

# Check if git is installed
if ! command -v git &> /dev/null; then
    echo "❌ Git not installed. Please install git first."
    exit 1
fi

# Check if we're in a git repo
if [ ! -d .git ]; then
    echo "⚠️ Not a git repository. Initializing..."
    git init
    git remote add origin https://github.com/YOUR_USERNAME/dgma-monitor.git
fi

# Create .env from .env.example
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cp .env.example .env
    echo "⚠️ Please edit .env with your credentials:"
    echo "  - TELEGRAM_TOKEN"
    echo "  - TELEGRAM_CHAT_ID"
    echo "  - DGMA_USERNAME"
    echo "  - DGMA_PASSWORD"
    echo "  - SHEET_ID"
fi

# Add files
echo "📦 Staging files..."
git add .

# Commit
echo "💾 Creating commit..."
git commit -m "DGMA Monitor - Initial setup" || echo "No changes to commit"

# Show next steps
echo ""
echo "✅ Setup complete!"
echo ""
echo "📋 Next steps:"
echo "1. Edit .env with your credentials"
echo "2. Create GitHub repository: https://github.com/new"
echo "3. Update origin URL: git remote set-url origin https://github.com/YOUR_USERNAME/dgma-monitor.git"
echo "4. Push to GitHub: git push -u origin main"
echo "5. Add GitHub Secrets: https://github.com/YOUR_USERNAME/dgma-monitor/settings/secrets/actions"
echo "6. Deploy Google Apps Script"
echo "7. Enable GitHub Actions"
echo ""
echo "🎉 Done! Your bot will run automatically on schedule."
